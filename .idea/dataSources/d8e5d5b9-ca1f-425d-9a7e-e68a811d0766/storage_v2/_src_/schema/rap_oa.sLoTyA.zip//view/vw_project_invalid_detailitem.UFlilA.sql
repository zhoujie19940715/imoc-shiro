create view vw_project_invalid_detailitem as select
                                               19                                    AS `table_id`,
                                               '费用报销单'                               AS `sheetname`,
                                               `a`.`index_id`                        AS `index_id`,
                                               `a`.`custom_id`                       AS `custom_id`,
                                               `a`.`f_203`                           AS `initiator`,
                                               `a`.`f_204`                           AS `appday`,
                                               `a`.`f_205`                           AS `areaname`,
                                               concat(`a`.`f_206`, ',', `a`.`f_208`) AS `appreason`,
                                               `a`.`f_209`                           AS `fundtype`,
                                               `a`.`f_210`                           AS `fundamount`,
                                               `t`.`sub_name`                        AS `standardfundtype`,
                                               `p`.`project_code`                    AS `project_code`,
                                               `p`.`project_name`                    AS `project_name`,
                                               `a`.`finish_date`                     AS `finish_date`,
                                               `a`.`status`                          AS `status`
                                             from ((`rap_oa`.`c19_fybxd` `a` left join `rap_oa`.`table_enumsub` `t`
                                                 on (((`t`.`sub_name` = `a`.`f_209`) and
                                                      (`t`.`type_id` = 131)))) left join `rap_oa`.`vw_project_valid` `p`
                                                 on ((`p`.`project_code` = `a`.`f_1856`)))
                                             where ((`a`.`f_1856` = '') or (not (exists(select 1
                                                                                        from
                                                                                          `rap_oa`.`table_enumsub` `s`
                                                                                        where ((`s`.`type_id` = 131) and
                                                                                               (`s`.`sub_name` =
                                                                                                `a`.`f_209`))))))
                                             union select
                                                     95                                      AS `table_id`,
                                                     '付款申请单'                                 AS `sheetname`,
                                                     `a`.`index_id`                          AS `index_id`,
                                                     `a`.`custom_id`                         AS `custom_id`,
                                                     `a`.`f_1176`                            AS `执行人`,
                                                     `a`.`f_1174`                            AS `执行时间`,
                                                     `a`.`f_1175`                            AS `地区`,
                                                     concat(`a`.`f_1177`, ',', `a`.`f_1178`) AS `理由`,
                                                     `a`.`f_1860`                            AS `费用类型`,
                                                     `a`.`f_1214`                            AS `金额`,
                                                     `t`.`sub_name`                          AS `标准费用类型`,
                                                     `p`.`project_code`                      AS `project_code`,
                                                     `p`.`project_name`                      AS `project_name`,
                                                     `a`.`finish_date`                       AS `finish_date`,
                                                     `a`.`status`                            AS `status`
                                                   from ((`rap_oa`.`c95_fukuanshenqingbiao` `a` left join
                                                     `rap_oa`.`table_enumsub` `t`
                                                       on (((`t`.`sub_name` = `a`.`f_1860`) and
                                                            (`t`.`type_id` = 131)))) left join
                                                     `rap_oa`.`vw_project_valid` `p`
                                                       on ((`p`.`project_code` = `a`.`f_1858`)))
                                                   where ((`a`.`f_1858` = '') or (not (exists(select 1
                                                                                              from
                                                                                                `rap_oa`.`table_enumsub` `s`
                                                                                              where
                                                                                                ((`s`.`type_id` = 131)
                                                                                                 and (`s`.`sub_name` =
                                                                                                      `a`.`f_1860`))))));

