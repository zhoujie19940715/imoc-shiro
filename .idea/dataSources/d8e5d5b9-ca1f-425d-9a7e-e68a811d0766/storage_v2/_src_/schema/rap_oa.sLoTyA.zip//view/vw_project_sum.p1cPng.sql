create view vw_project_sum as select
                                `rap_oa`.`c140_project`.`custom_id`             AS `custom_id`,
                                `rap_oa`.`c140_project`.`f_1802`                AS `project_code`,
                                `rap_oa`.`c140_project`.`f_1803`                AS `project_name`,
                                `rap_oa`.`c140_project`.`f_1804`                AS `depart_name`,
                                `rap_oa`.`c140_project`.`f_1805`                AS `sale_type`,
                                `rap_oa`.`c140_project`.`f_1806`                AS `build_name`,
                                substr(`rap_oa`.`c140_project`.`f_1807`, 1, 10) AS `build_time`,
                                NULL                                            AS `receive_amount`,
                                NULL                                            AS `contract_fund`,
                                NULL                                            AS `manage_fund`,
                                NULL                                            AS `budget_fund`,
                                NULL                                            AS `real_cost`,
                                NULL                                            AS `sale_cost`,
                                NULL                                            AS `profit_fund`
                              from `rap_oa`.`c140_project`
                              where
                                ((`rap_oa`.`c140_project`.`f_1813` <> '') and (`rap_oa`.`c140_project`.`status` = '13'))
                              union select
                                      `rap_oa`.`c141_projectapproval`.`custom_id`             AS `custom_id`,
                                      `rap_oa`.`c141_projectapproval`.`f_1819`                AS `project_code`,
                                      `rap_oa`.`c141_projectapproval`.`f_1820`                AS `project_name`,
                                      `rap_oa`.`c141_projectapproval`.`f_1818`                AS `depart_name`,
                                      `rap_oa`.`c141_projectapproval`.`f_1822`                AS `sale_type`,
                                      `rap_oa`.`c141_projectapproval`.`f_1823`                AS `build_name`,
                                      substr(`rap_oa`.`c141_projectapproval`.`f_1821`, 1, 10) AS `build_time`,
                                      NULL                                                    AS `receive_amount`,
                                      NULL                                                    AS `contract_fund`,
                                      NULL                                                    AS `manage_fund`,
                                      NULL                                                    AS `budget_fund`,
                                      NULL                                                    AS `real_cost`,
                                      NULL                                                    AS `sale_cost`,
                                      NULL                                                    AS `profit_fund`
                                    from `rap_oa`.`c141_projectapproval`
                                    where (`rap_oa`.`c141_projectapproval`.`status` = '13');

