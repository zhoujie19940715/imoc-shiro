create view vw_project_valid as select
                                  `rap_oa`.`c140_project`.`f_1802` AS `project_code`,
                                  `rap_oa`.`c140_project`.`f_1803` AS `project_name`
                                from `rap_oa`.`c140_project`
                                where (`rap_oa`.`c140_project`.`status` = 13)
                                union select
                                        `rap_oa`.`c141_projectapproval`.`f_1819` AS `project_code`,
                                        `rap_oa`.`c141_projectapproval`.`f_1820` AS `project_name`
                                      from `rap_oa`.`c141_projectapproval`
                                      where (`rap_oa`.`c141_projectapproval`.`status` = 13);

